from setuptools import setup, find_packages

setup(
    name='Hotamov_Chat_Test',
    version='1.0',
    author="Hotamov Suhrob",
    author_email= "suhrobhotamov496@gmail.com",
    packages=find_packages(),
)